/*
 * @Author: hawrkchen
 * @Date: 2025-03-04 17:12:35
 * @LastEditors: Do not edit
 * @LastEditTime: 2025-03-05 15:23:45
 * @Description: 
 * @FilePath: /curl_cpp/main.cpp
 */
#include <iostream>
#include <fstream>
#include <string>
#include <curl/curl.h>

class CurlDownloader {
public:
    CurlDownloader() : curl_(curl_easy_init()), file_(nullptr), offset_(0) {
        if (!curl_) {
            throw std::runtime_error("Failed to initialize libcurl.");
        }
    }

    ~CurlDownloader() {
        if (curl_) {
            curl_easy_cleanup(curl_);
        }
        if (file_) {
            fclose(file_);
        }
    }

    bool download(const std::string& url, const std::string& output_file) {
        // 打开文件，检查是否支持断点续传
        file_ = fopen(output_file.c_str(), "ab");
        if (!file_) {
            std::cerr << "Failed to open file: " << output_file << std::endl;
            return false;
        }

        // 获取当前文件大小，用于断点续传
        fseek(file_, 0, SEEK_END);
        offset_ = ftell(file_);

        // 设置CURL选项
        curl_easy_setopt(curl_, CURLOPT_URL, url.c_str());
        curl_easy_setopt(curl_, CURLOPT_WRITEDATA, file_);
        // 设置回调函数
        curl_easy_setopt(curl_,CURLOPT_XFERINFOFUNCTION,progressCallback);
        curl_easy_setopt(curl_,CURLOPT_XFERINFODATA,this);
        curl_easy_setopt(curl_, CURLOPT_NOPROGRESS, 0L);
        curl_easy_setopt(curl_, CURLOPT_RESUME_FROM_LARGE, offset_);

        // 执行下载
        CURLcode res = curl_easy_perform(curl_);
        if (res != CURLE_OK) {
            std::cerr << "Download failed: " << curl_easy_strerror(res) << std::endl;
            return false;
        }

        std::cout << "Download completed successfully." << std::endl;
        return true;
    }

    void get_upgrade_pkg_size(const std::string& url) {
        long long contentLength = 0;

        curl_easy_setopt(curl_, CURLOPT_URL, url.c_str());
        // 设置只发送HTTP HEAD请求
        curl_easy_setopt(curl_, CURLOPT_NOBODY, 1L);
        // 设置回调函数
        curl_easy_setopt(curl_, CURLOPT_HEADERFUNCTION, header_callback);

        curl_easy_setopt(curl_, CURLOPT_HEADERDATA, &contentLength);
        // 执行请求
        CURLcode res = curl_easy_perform(curl_);
        if (res != CURLE_OK) {
            std::cerr << "Failed to get upgrade package size: " << curl_easy_strerror(res) << std::endl;
        }   
        std::cout << "Content-Length: " << contentLength << " bytes" << std::endl;
    }

private:
    static int progressCallback(void* clientp, curl_off_t dltotal, curl_off_t dlnow, curl_off_t ultotal, curl_off_t ulnow) {
        CurlDownloader* downloader = static_cast<CurlDownloader*>(clientp);
        static int count = 0;
        static const int printInterval = 100;
        if (dltotal > 0) {
            if(count > 0 && count % printInterval == 0) {
                double progress = static_cast<double>(dlnow) / dltotal * 100.0;
                std::cout << "Download progress: " << progress << "%" << std::endl;
            } 
            count++;

        }
        return 0;
    }

    static size_t header_callback(char* buffer, size_t size, size_t nitems, void* userdata) {
        size_t totalSize = size * nitems;
        std::string header(buffer, totalSize);
        if (header.find("Content-Length:") != std::string::npos) {
            size_t pos = header.find(":") + 2;
            std::string lengthStr = header.substr(pos, header.find("\r", pos) - pos);
            long contentLength = std::stol(lengthStr);
            //std::cout << "Content-Length: " << contentLength << " bytes" << std::endl;
            *static_cast<long long*>(userdata) = contentLength;
        }
        //std::cout << "get totalSize: "   << totalSize << std::endl;
        return totalSize;
    }

    CURL* curl_;
    FILE* file_;
    long offset_;
};

int main() {
    CurlDownloader downloader;

    std::string url = "https://ftp.gnu.org/gnu/wget/wget2-latest.tar.gz";
    std::string output_file = "wget2-latest.tar.gz";

    downloader.get_upgrade_pkg_size(url);

    // if (downloader.download(url, output_file)) {
    //     std::cout << "File downloaded successfully." << std::endl;
    // } else {
    //     std::cerr << "File download failed." << std::endl;
    // }

    std::cin.get();

    return 0;
}